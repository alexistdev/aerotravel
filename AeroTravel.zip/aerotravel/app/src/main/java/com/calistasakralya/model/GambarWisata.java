package com.calistasakralya.model;

public class GambarWisata {
    private final String gambar;

    public GambarWisata(String gambar) {
        this.gambar = gambar;
    }

    public String getGambar() {
        return gambar;
    }

}
