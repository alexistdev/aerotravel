package com.calistasakralya.config;

public class Constants {
//    public static final String IMAGES_URL = "http://192.168.56.1/aerotravelweb/gambar/";
//    public static final String URL ="http://192.168.56.1/aerotravelweb/";
    public static final String URL ="http://www.aerotravel.xyz/";
    public static final String IMAGES_URL = "http://www.aerotravel.xyz/gambar/";

    //Key Session
    public static final String KEY_USER_SESSION = "RSK123456";
    public static final String USER_SESSION = "BKD858";
}
